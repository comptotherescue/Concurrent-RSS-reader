import { Injectable } from '@angular/core';
import {Http,Headers} from '@angular/http';
import {Contact} from './Contact';
import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  constructor(private:http : Http) { }
}

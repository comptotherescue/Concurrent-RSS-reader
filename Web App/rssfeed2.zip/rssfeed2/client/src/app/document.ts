export class Document{
  _id?:string;
  _date:string;
  _title:string;
  _description:string;
  _link:string;
}
